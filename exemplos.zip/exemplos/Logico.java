//Logico.java
public class Logico{
    public static void main(String args[]){
        boolean verdadeiro = true;
        boolean falso = false;
        System.out.println("Verdadeiro:  " +verdadeiro);
        System.out.println("Falso: " +falso);
    }
}