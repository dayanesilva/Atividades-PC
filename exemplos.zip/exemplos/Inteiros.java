//Inteiros.java
public class Inteiros{
    public static void main(String args[]){
        byte varByte = 10;
        short varShort = 32000;
        int varInt = 2000000000;
        long varLong = 3000000000L;
        System.out.println("Byte: " +varByte);
        System.out.println("Short: " +varShort);
        System.out.println("Int: " +varInt);
        System.out.println("Long: " +varLong);
    }
}