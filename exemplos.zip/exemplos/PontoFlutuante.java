//PontoFlutuante.java
public class PontoFlutuante{
    public static void main(String args[]){
        double varDouble = 45.06;
        float varFloat = 3.1415927f;
        //A letra f, indica que o valor deve ser tratado como float
        System.out.println("Double: " +varDouble);
        System.out.println("Float: " +varFloat);
    }
}