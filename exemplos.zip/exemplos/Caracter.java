//Caracter.java
public class Caracter{
    public static void main(String args[]){
        char letraE = 'E';
        char letraD = 100;
        char letraN = '\u004E';
        
        System.out.println("Letra E= " +letraE);
        System.out.println("Letra D= " +letraD);
        System.out.println("Letra N= " +letraN);
    }
}