//Texto.java
public class Texto{
    public static void main(String args[]){
        String nome = "João";
        String sobrenome = "da Silva";
        System.out.println("Nome Completo: " +nome + " " +sobrenome);
    }
}