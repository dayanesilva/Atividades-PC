//Aritmetica.java
public class Aritmetica{
    public static void main(String args[]){
        int x = 10;		 int y = 4;	 
        int soma = x+y;	 	 int subtracao = x-y;	 int multiplicacao = x*y;
        int divisao = x/y;	 	 int resto = x%y;	

        System.out.println("Soma: " + soma);
        System.out.println("Subtracao: " + subtracao);
        System.out.println("Multiplicacao: " + multiplicacao);
        System.out.println("Divisao: " + divisao);
        System.out.println("Resto: " + resto);
    }
}