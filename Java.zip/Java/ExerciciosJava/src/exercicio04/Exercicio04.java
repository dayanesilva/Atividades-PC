/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercicio04;

import java.util.Scanner;
/**
 *
 * @author dayan
 */
public class Exercicio04 {
    public static void main(String[] args){
        System.out.println("Preço do Terreno");
        
        double b, h, preco, total, area;
		
	System.out.println("\nInforme o valor da base do terreno: ");
	Scanner lerb = new Scanner(System.in);
	b = lerb.nextFloat();
		
	System.out.println("\nInforme o valor da altura do terreno: ");
	Scanner lerh = new Scanner(System.in);
	h = lerh.nextFloat();
		
	System.out.println("\nInforme o preço do metro quadrado: ");
	Scanner lerp = new Scanner(System.in);
	preco = lerp.nextFloat();
		
	area = b * h;
	total = area * preco;
		
	System.out.println("\nPreço do terreno: R$" +total);
    }
}
