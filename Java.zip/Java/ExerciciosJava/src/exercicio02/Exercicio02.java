/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercicio02;
import java.util.Scanner;
/**
 *
 * @author dayan
 */
public class Exercicio02 {
    public static void main(String[] args){
        System.out.println("Área do Triângulo");
      
        double b, h, area;
		
	System.out.println("\nInforme o valor da base do triângulo: ");
	Scanner lerb = new Scanner(System.in);
	b = lerb.nextDouble();
		
	System.out.println("\nInforme o valor da altura do triângulo: ");
	Scanner lerh = new Scanner(System.in);
	h = lerh.nextDouble();
		
	area = (b * h) / 2;
		
	System.out.println("\nÁrea: " +area);
    }
    
}
 