/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercicio03;

import java.util.Scanner;
/**
 *
 * @author dayan
 */
public class Exercicio03 {
    public static void main(String[] args){
        System.out.println("Área do Círculo");
        
        double r, area, pi;
	pi = 3.14;
		
	System.out.println("\nInforme o valor do raio do círculo: ");
	Scanner lerraio = new Scanner(System.in);
	r = lerraio.nextDouble();
		
	area = pi * (r * r);
		
	System.out.println("\nÁrea: " +area);
    }
}
