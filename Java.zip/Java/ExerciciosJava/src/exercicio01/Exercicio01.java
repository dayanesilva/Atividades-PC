/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercicio01;

import java.util.Scanner;
/**
 *
 * @author dayan
 */
public class Exercicio01 {
    public static void main(String[] args){
        System.out.println("Média");
        
        float n1, n2, n3, n4, soma, media;
		
	System.out.println("\nInforme o primeiro número: ");
	Scanner ler1 = new Scanner(System.in);
	n1 = ler1.nextFloat();
		
	System.out.println("\nInforme o segundo número: ");
	Scanner ler2 = new Scanner(System.in);
	n2 = ler2.nextFloat();
		
	System.out.println("\nInforme o terceiro número: ");
	Scanner ler3 = new Scanner(System.in);
	n3 = ler3.nextFloat();
		
	System.out.println("\nInforme o quarto número: ");
	Scanner ler4 = new Scanner(System.in);
	n4 = ler4.nextFloat();
		
	soma = n1+n2+n3+n4;
	media = soma / 4;
		
	System.out.println("\nSoma: " +soma);
	System.out.println("\nMédia: " +media);
    }
}
