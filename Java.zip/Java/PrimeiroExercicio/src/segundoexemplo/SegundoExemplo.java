/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package segundoexemplo;

import java.util.Scanner;

/**
 *
 * @author dayan
 */
public class SegundoExemplo {
    public static void main(String[] args){
        //declaração das duas variáveis inicializadas em zero.
        int n1 = 0, result = 0;
        
        Scanner leia = new Scanner(System.in);
        
        System.out.println("Informe o número: ");
        n1 = leia.nextInt();
        
        result = n1 * n1 * n1;
        
        System.out.println("O resultado é: " +result);
    }
}
