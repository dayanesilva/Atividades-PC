import java.util.Scanner;
//Terreno.java
public class Terreno{
    public static void main(String args[]){
        Scanner ler = new Scanner(System.in);
        int frente = 0;
        int lado = 0;	 
        double preco = 0;	 	
        
        System.out.println("Informe a medida da frente do terreno, em metros: ");
        frente = ler.nextInt();
        System.out.println("Informe a medida do lado do terreno, em metros: ");
        lado = ler.nextInt();
        System.out.println("Informe o preco do metro quadrado do terreno: ");
        preco = ler.nextDouble();

        int area = frente*lado;
        double total = area*preco;

        System.out.println("Preco de venda do terreno: " + total);
    }
}