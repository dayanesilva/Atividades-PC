import java.util.Scanner;
//Desafio.java
public class Desafio{
    public static void main(String args[]){
        Scanner ler = new Scanner(System.in);
        int n = 0;
        int casa = 1;
        int cont = 10;	 	 	
        
        System.out.println("Informe um numero: ");
        n = ler.nextInt();

        if (n<0){
    	    n = n*(-1);
        }
        
        while(cont<=n){
	        
	        casa++;
	        cont = cont*10;
         }

        System.out.println("O numero possui " +casa+ " casa(s).");
        
    }
}