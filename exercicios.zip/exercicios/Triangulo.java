import java.util.Scanner;
//Triangulo.java
public class Triangulo{
    public static void main(String args[]){
        Scanner ler = new Scanner(System.in);
        int base = 0;
        int altura = 0;	 	 	
        
        System.out.println("Informe a base do triangulo: ");
        base = ler.nextInt();
        System.out.println("Informe a altura do triangulo: ");
        altura = ler.nextInt();

        int area = (base*altura)/2;
        System.out.println("Area do Triangulo: " + area);
    }
}