import java.util.Scanner;
//QuadradoSoma.java
public class QuadradoSoma{
    public static void main(String args[]){
        Scanner ler = new Scanner(System.in);
        int n1 = 0;
        int n2 = 0;
        int n3 = 0;	 	 	
        
        System.out.println("Primeiro valor: ");
        n1 = ler.nextInt();
        System.out.println("Segundo valor: ");
        n2 = ler.nextInt();
        System.out.println("Terceiro valor: ");
        n3 = ler.nextInt();

        int soma = n1+n2+n3;
        int quadrado = soma*soma;

        System.out.println("Soma: " + soma);
        System.out.println("Quadrado da soma: " + quadrado);
    }
}