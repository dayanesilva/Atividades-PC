package jobCourseJava;
import java.util.Scanner;

public class mainPrograming {
	public static void main(String[] args){
		// vari�vel num � um inteiro
		
		/* Aula 07
		 * Coment�rios
		 */
		
		int num;
		
		/*Aula 08
		 * Vari�veis
		 */
		
		int numero;
		int Numero;
		
		/*Aula 09
		 * Inteiro
		 */
		
		//int n;
		//n = 10;
		
		int n = 10;
		
		System.out.println(n);
		
		int a = 10/3;
		
		System.out.println(a);
		
		// int num = 4276192719383; ultrapassou qtde m�xima
		
		/*Aula 10
		 * Float
		 */
		
		float b = 10.8f;
		
		System.out.println(b);
		
		float b1 = 10;
		
		float b2 = 3;
		
		System.out.println(b1/b2);
		
		/*Aula 11
		 * Double
		 */
		
		//double tem uma qtde caracteres maior que o float
		
		double c = 10.5;
		double c1 = 15.6;
		
		System.out.println(c/c1);
		
		
		/*Aula 12
		 * String
		 */
		
		String nome = "Maria"; 
		System.out.println(nome);
		
		String number = "2643928"; 
		System.out.println(number);
		
		String caracter = "!*#%$@"; 
		System.out.println(caracter);
		
		String flutuantes = "10.69"; 
		System.out.println(flutuantes);
		
		String aspas = "\"Maria\""; 
		System.out.println(aspas);
		
		/*Aula 13
		 * Entrada de Dados
		 */
		
		System.out.println("Entre com seu nome: ");
		Scanner lernome = new Scanner(System.in);
		String nome1 = lernome.next();
		
		System.out.println("Entre com sua idade: ");
		Scanner leridade = new Scanner(System.in);
		int idade = leridade.nextInt();
		
		System.out.println("Entre com sua renda: ");
		Scanner lerrenda = new Scanner(System.in);
		float renda = lerrenda.nextFloat();
		
		System.out.println("Meu nome � " +nome1 + " e tenho " + idade+ " anos. Minha renda � de R$" +renda);
		
	}
}
