package jobCourseJava;

public class Operadores {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		/* Aula 14
		 * Soma
		 */
		
		System.out.println("Soma");
		
		int a, b;
		a = 10;
		b = 25;
		
		int soma = a + b + 5;
		
		System.out.println(soma);
		System.out.println(a+b);
		
		
		/* Aula 15
		 * Subtra��o
		 */
		
		System.out.println("Subtra��o");
		
		int c, d, sub;
		c = 10;
		d = 15;
		sub = c - d;
		
		System.out.println(sub - 5);
		System.out.println(c-d);
		
		
		/* Aula 16
		 * Multiplica��o
		 */
		
		System.out.println("Multiplica��o");
		
		int x, y, z, z1;
		x = 3;
		y = 5;
		z = x * y;
		z1 = x * y * (-1);
		
		System.out.println(z*9);
		System.out.println(z1);
		System.out.println(x * y);
		
		
		/* Aula 17
		 * Divis�o e Mode
		 */
		
		System.out.println("Divis�o e Mode");
		
		float m, n, divisao;
		float mode;
		
		m = 20;
		n = 3;
		divisao = m / n;
		mode = m % n;
		
		System.out.println(divisao);
		System.out.println(mode);
		
		
		/* Aula 18
		 * Concatena��o
		 */
		
		System.out.println("Concatena��o");
		
		int f, g, h;
		f = 10;
		g = 8;
		h = f+g;
		
		String i, j;
		i = "Jos�";
		j = " Silva";
	
		
		System.out.println(f+g);
		System.out.println("Meu nome � " + i+j + " tenho " + h + " anos");
		
		
		
		/* Aula 19
		 * Incremento e Decremento
		 */
		
		System.out.println("\nIncremento");
		
		int k;
		k = 0;
		//k = k + 1;
		k++;
		k++;
		k++;
		
		System.out.println(k);
		System.out.println("\nIncremento 2 em 2");
		
		k = 0;
		k += 2;
		k += 2;
		
		System.out.println(k);
		System.out.println("\nIncremento 6 em 6");
		
		k = 0;
		k += 6;
		
		System.out.println(k);
		System.out.println("\nDecremento");
		
		int k1;
		k = 0;
		//k = k - 1;
		k--;
		
		System.out.println(k);
		System.out.println("\nDecremento 6 em 6");
		
		k = 0;
		k-=6;
		
		System.out.println(k);
		System.out.println("\nDividindo");
		
		k = 50;
		k/=5;
		k/=5;
		
		System.out.println(k);
		System.out.println("\nMultiplicando");
		
		k = 10;
		k*=10;
		k*=10;
		k*=10;
		
		System.out.println(k);
		
		
		/* Aula 20
		 * Operadores Relacionais
		 */
		
		//10 < 5 = false;   menor
		//10 > 5 = true;  maior
		//10 == 5 = false   igual
		//10 == 10 = true
		
		
		/* Aula 21
		 * Operadores Relacionais Combinados
		 */
		
		//10 < 5 = false;   menor
		//10 > 5 = true;  maior
		//10 == 5 = false   igual
		//10 == 10 = true
		
		//10 <= 10 = true;  menor igual
		//10 >= 10 = true;  maior igual
		//20 != 10 = true;  nega��o, diferente
		
	}
	

}
