package jobCourseJava;
import java.util.Scanner;

public class Estrutura {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Aula 22 - For
		System.out.println("\nFor");
		
		for(int i = 0; i <= 21; i++){
			System.out.println("O valor de i � " +i);
		}
		
		int j;
		
		for(j = 0; j <= 20; j+=2){
			System.out.println("O valor de j � " +j);
		}
		
		System.out.println("Ol�");
		
		//Aula 23 - While
		System.out.println("\nWhile");
		
		int n = 0;
		
		while(n<20) {
			System.out.println("n est� valendo " +n);
			n++;
		}
		
		
		//Aula 24 - Do While
		System.out.println("\nDo While");
		
		int a = 0;
		
		do{
			System.out.println("Ol�");
			System.out.println("O valor de a � " +a);
			a++;
		}while(a<20);
		
		
		int a1 = 0;
		
		do{
			System.out.println("Ol�");
			System.out.println("O valor de a1 � " +a1);
			a1++;
		}while(a1<0);
		
		
		
		//Aula 25 - For Each - leitura de listas
		System.out.println("\nFor Each");
		
		String[] lista = {"Ana", "Maria", "Jo�o", "Jos�"};
		
		for(String x:lista) {
			System.out.println(x);
		}
		
		
		//Aula 26 - If
		System.out.println("\nIf");
				
		int idade = 18;
				
		if(idade >= 18) {
			System.out.println("Sim");
		}else {
			System.out.println("N�o");
		}
		
		
		String name = "Maria";
		if(name.equals("Jos�")) {
			System.out.println("Sim");
		}else {
			System.out.println("N�o");
		}
		
		
		//Aula 27 - Operadores L�gicos
		/* e - &&
		 * ou - ||
		 * not - !
		 */
		
		System.out.println("\nOperadores L�gicos");
						
		int n1 = 10, n2 = 5;
		
		if((n1 > n2) && (n2 == n1)) {
			System.out.println("Sim");
		}else {
			System.out.println("N�o");
		}
		
		if((n1 > n2) || (n2 == n1)) {
			System.out.println("Sim");
		}else {
			System.out.println("N�o");
		}
		
		if(!(n1 > n2)){
			System.out.println("Sim");
		}else {
			System.out.println("N�o");
		}
		
		
		//Aula 28 - If Aninhado - filtrar informa��es
				
		System.out.println("\nIf Aninhado");
								
		int x = 9, y = 5;
				
		if(x > 0) {
			if(x < 10) {
				System.out.println("Sim");
				if(x > 5) {
					System.out.println("Sim2");
					if(y > 19) {
						System.out.println("Sim3");
					}
				}
			}
		}else {
			System.out.println("N�o");
		}
		
		
		//Aula 29 - Else If
		System.out.println("\nElse If");
						
		int num = 10;
						
		if(num == 9) {
			System.out.println("n9");
		}else if(num == 8) {
			System.out.println("n8");
		}else if(num == 7) {
			System.out.println("n7");
		}else if(num == 6) {
			System.out.println("n6");
		}else if(num == 5) {
			System.out.println("n5");
		}else {
			System.out.println("N�o encontrado");
		}
		
		
		//Aula 30 - Swicth
		System.out.println("\nSwitch");
		String mes = ("Janeiro");
		
		switch(mes){
		case "Janeiro":
			System.out.println("Janeiro");
			break;
		default: 
			System.out.println("M�s Incorreto");
			break;
		}
		
		
		
		int ano = 12;
		
		switch(ano) {
		
		case 1:
			System.out.println("Janeiro");
			break;
		case 2:
			System.out.println("Fevereiro");
			break;
		case 3:
			System.out.println("Mar�o");
			break;
		case 4:
			System.out.println("Abril");
			break;
		case 5:
			System.out.println("Maio");
			break;
		case 6:
			System.out.println("Junho");
			break;
		case 7:
			System.out.println("Julho");
			break;
		case 8:
			System.out.println("Agosto");
			break;
		case 9:
			System.out.println("Setembro");
			break;
		case 10:
			System.out.println("Outubro");
			break;
		case 11:
			System.out.println("Novembro");
			break;
		case 12:
			System.out.println("Dezembro");
			break;
		
		default: 
			System.out.println("M�s Incorreto");
			break;
		}
		
		
		//Aula 31 - Try Catch
		//tratamento de erros
		System.out.println("\nTry Catch");
		
		try {
			int r = 10/0;
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}
		
		
		//Aula 32 - Matrizes
		System.out.println("\nMatrizes");
		
		int[] numeros = new int[4];
		String[] palavras = new String[2];
		
		numeros[0] = 2;
		numeros[1] = 4;
		numeros[2] = 3;
		numeros[3] = 1;
		palavras[0] = "Maria";
		palavras[1] = "Silva";
		
		System.out.println(numeros[1]+numeros[2]);
		System.out.println(palavras[0]+palavras[1]);
		
		
		
		//Aula 33 - Indices
		System.out.println("\n�ndices");
		
		int[] arreio = new int[3];
		
		Scanner ler;
		ler = new Scanner(System.in);
		
		int i1;
		
		for(i1 = 0; i1 < arreio.length; i1++) {
			System.out.println("Informe um n�mero: ");
			arreio[i1] = ler.nextInt();
		}
		for(i1 = 0; i1 < arreio.length; i1++) {
			System.out.println(arreio[i1]);
		}
			
		
		
		//Aula 32 - Matriz Bidimencional
		System.out.println("\nMatriz Bidimencional");
				
		//int[] numeros1 = new int[2];
		int[][] bi = new int[2][2];
			
		Scanner ler1;
		
		int t, v;
		ler1 = new Scanner(System.in);
		
		for(t = 0; t < bi.length; t++) {
			for(v = 0; v < bi.length; v++) {
				System.out.println("Insira um n�mero: ");
				bi[t][v] = ler1.nextInt();
			}
		}
		
		for(t = 0; t < bi.length; t++) {
			for(v = 0; v < bi.length; v++) {
				System.out.println(bi[t][v]);
				
			}
		}
				
	}
}
