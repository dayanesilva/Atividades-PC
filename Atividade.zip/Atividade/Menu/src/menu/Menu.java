/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package menu;
import java.util.Scanner;
/**
 *
 * @author dayan
 */
public class Menu {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
            int opcao = 0, num = 0;
            Scanner ler = new Scanner(System.in);
           
            System.out.println("\nExercícios");
            System.out.println("[1]- Escrever número por extenso");
            System.out.println("[2]- Escrever invertido");
            System.out.println("[0]- Sair");

            do
            {
                System.out.println("\nOpcão:\n");
                opcao = ler.nextInt();

                switch (opcao)
                {
                    case 1:
                        {
                        int u, d, c, m;
                        String unidade = " ", dezena = " ", centena = " ", milhar = " ";
         
                        System.out.println("\nInforme um número: \n");
                        num = ler.nextInt();

                        if (num > 9999)
                        {
                            System.out.println("Valor Inválido!");
                            System.out.println(" ");
                        }

                        u = (num % 1000) % 10;

                        d = (num / 10) % 10;

                        c = (num % 1000) / 100;

                        m = num / 1000;

                        //Milhar

                        if (m == 0)
                        {
                             milhar = " ";
                        }

                        if (m == 1 && c == 0 && d == 0 && u == 0)
                        {
                             milhar = "Mil";
                        }

                        else if (m == 1 && c == 0)
                        {
                             milhar = "Mil e ";
                        }

                        else if (m == 1 && c != 0)
                        {
                             milhar = "Mil ";
                        }

                        if (m == 2 && c == 0 && d == 0 && u == 0)
                        {
                            milhar = "Dois Mil";
                        }

                        else if (m == 2 && c == 0)
                        {
                             milhar = "Dois Mil e ";
                        }

                        if (m == 2 && c != 0)
                        {
                             milhar = "Dois Mil ";
                        }

                        if (m == 3 && c == 0 && d == 0 && u == 0)
                        {
                            milhar = "Três Mil";
                        }

                        else if (m == 3 && c == 0)
                        {
                             milhar = "Três Mil e ";
                        }

                        else if (m == 3 && c != 0)
                        {
                             milhar = "Três Mil ";
                        }

                        if (m == 4 && c == 0 && d == 0 && u == 0)
                        {
                             milhar = "Quatro Mil";
                        }

                        else if (m == 4 && c == 0)
                        {
                             milhar = "Quatro Mil e ";
                        }

                        else if (m == 4 && c != 0)
                        {
                             milhar = "Quatro Mil ";
                        }

                        if (m == 5 && c == 0 && d == 0 && u == 0)
                        {
                            milhar = "Cinco Mil";
                        }

                        else if (m == 5 && c == 0)
                        {
                            milhar = "Cinco Mil e ";
                        }

                        else if (m == 5 && c != 0)
                        {
                            milhar = "Cinco Mil ";
                        }

                        if (m == 6 && c == 0 && d == 0 && u == 0)
                        {
                            milhar = "Seis Mil";
                        }

                        else if (m == 6 && c == 0)
                        {
                            milhar = "Seis Mil e ";
                        }

                        else if (m == 6 && c != 0)
                        {
                            milhar = "Seis Mil ";
                        }

                        if (m == 7 && c == 0 && d == 0 && u == 0)
                        {
                            milhar = "Sete Mil";
                        }

                        else if (m == 7 && c == 0)
                        {
                            milhar = "Sete Mil e ";
                        }

                        else if (m == 7 && c != 0)
                        {
                           milhar = "Sete Mil ";
                        }

                        if (m == 8 && c == 0 && d == 0 && u == 0)
                        {
                            milhar = "Oito Mil";
                        }

                        else if (m == 8 && c == 0)
                        {
                            milhar = "Oito Mil e ";
                        }

                        else if (m == 8 && c != 0)
                        {
                            milhar = "Oito Mil ";
                        }

                        if (m == 9 && c == 0 && d == 0 && u == 0)
                        {
                            milhar = "Nove Mil";
                        }

                        else if (m == 9 && c == 0)
                        {
                            milhar = "Nove Mil e ";
                        }

                        else if (m == 9 && c != 0)
                        {
                            milhar = "Nove Mil ";
                        }

                        //Centena

                        if (c == 0)
                        {
                            centena = " ";
                        }

                        if (c == 1 && d == 0 && u == 0)
                        {
                            centena = "Cem";
                        }

                        else if (c == 1)
                        {
                            centena = "Cento e ";
                        }

                        if (c == 2 && d == 0 && u == 0)
                        {
                            centena = "Duzentos";
                        }

                        else if (c == 2)
                        {
                            centena = "Duzentos e ";
                        }

                        if (c == 3 && d == 0 && u == 0)
                        {
                            centena = "Trezentos";
                        }

                        else if (c == 3)
                        {
                            centena = "Trezentos e ";
                        }

                        if (c == 4 && d == 0 && u == 0)
                        {
                            centena = "Quatrocentos";
                        }

                        else if (c == 4)
                        {
                           centena = "Quatrocentos e ";
                        }

                        if (c == 5 && d == 0 && u == 0)
                        {
                            centena = "Quinhentos";
                        }

                        else if (c == 5)
                        {
                            centena = "Quinhentos e ";
                        }

                        if (c == 6 && d == 0 && u == 0)
                        {
                            centena = "Seiscentos";
                        }

                        else if (c == 6)
                        {
                           centena = "Seiscentos e ";
                        }

                        if (c == 7 && d == 0 && u == 0)
                        {
                            centena = "Setecentos";
                        }

                        else if (c == 7)
                        {
                            centena = "Setecentos e ";
                        }

                        if (c == 8 && d == 0 && u == 0)
                        {
                            centena = "Oitocentos";
                        }

                        else if (c == 8)
                        {
                           centena = "Oitocentos e ";
                        }

                        if (c == 9 && d == 0 && u == 0)
                        {
                            centena = "Novecentos";
                        }

                        else if (c == 9)
                        {
                            centena = "Novecentos e ";
                        }

                        //Dezena

                        if (d == 0)
                        {
                            dezena = " ";
                        }

                        if (d == 1 && u == 0)
                        {
                            dezena = "Dez";
                        }

                        if (d == 1 && u == 1)
                        {
                            dezena = "Onze";
                        }

                        if (d == 1 && u == 2)
                        {
                            dezena = "Doze";
                        }

                        if (d == 1 && u == 3)
                        {
                            dezena = "Treze";
                        }

                        if (d == 1 && u == 4)
                        {
                            dezena = "Quatorze";
                        }

                        if (d == 1 && u == 5)
                        {
                            dezena = "Quinze";
                        }

                        if (d == 1 && u == 6)
                        {
                           dezena = "Dezesseis";
                        }

                        if (d == 1 && u == 7)
                        {
                            dezena = "Dezessete";
                        }

                        if (d == 1 && u == 8)
                        {
                            dezena = "Dezoito";
                        }

                        if (d == 1 && u == 9)
                        {
                            dezena = "Dezenove";
                        }

                        if (d == 2 && u == 0)
                        {
                            dezena = "Vinte";
                        }

                        else if (d == 2)
                        {
                            dezena = "Vinte e ";
                        }

                        if (d == 3 && u == 0)
                        {
                           dezena = "Trinta";
                        }

                        else if (d == 3)
                        {
                             dezena = "Trinta e ";
                        }

                        if (d == 4 && u == 0)
                        {
                             dezena = "Quarenta";
                        }

                        else if (d == 4)
                        {
                            dezena = "Quarenta e ";
                        }

                        if (d == 5 && u == 0)
                        {
                            dezena = "Cinquenta";
                        }

                        else if (d == 5)
                        {
                            dezena = "Cinquenta e ";
                        }

                        if (d == 6 && u == 0)
                        {
                            dezena = "Sessenta";
                        }

                        else if (d == 6)
                        {
                            dezena = "Sessenta e ";
                        }

                        if (d == 7 && u == 0)
                        {
                            dezena = "Setenta";
                        }

                        else if (d == 7)
                        {
                            dezena = "Setenta e ";
                        }

                        if (d == 8 && u == 0)
                        {
                            dezena = "Oitenta";
                        }

                        else if (d == 8)
                        {
                            dezena = "Oitenta e ";
                        }

                        if (d == 9 && u == 0)
                        {
                            dezena = "Noventa";
                        }

                        else if (d == 9)
                        {
                            dezena = "Noventa e ";
                        }

                        //Unidade

                        if (u == 0)
                        {
                            unidade = " ";
                        }

                        if (u == 1 && d != 1)
                        {
                            unidade = "Um";
                        }

                        if (u == 2 && d != 1)
                        {
                            unidade = "Dois";
                        }

                        if (u == 3 && d != 1)
                        {
                            unidade = "Três";
                        }

                        if (u == 4 && d != 1)
                        {
                            unidade = "Quatro";
                        }

                        if (u == 5 && d != 1)
                        {
                            unidade = "Cinco";
                        }

                        if (u == 6 && d != 1)
                        {
                            unidade = "Seis";
                        }

                        if (u == 7 && d != 1)
                        {
                            unidade = "Sete";
                        }

                        if (u == 8 && d != 1)
                        {
                            unidade = "Oito";
                        }

                        if (u == 9 && d != 1)
                        {
                             unidade = "Nove";
                        }

                        System.out.println(milhar + centena + dezena + unidade);
                        
                        System.out.println("\nExercícios");
                        System.out.println("[1]- Escrever número por extenso");
                        System.out.println("[2]- Escrever invertido");
                        System.out.println("[0]- Sair");

                    }
                    break;

                case 2:
                    {
                        String n = " ", n1 = " ";
                        System.out.println("\nEscreva algo: \n");
                        n = ler.next();
      
                        for(int i = n.length() - 1; i >= 0; i--){
                            n1 = n1 + n.charAt(i);
                        }
                            System.out.println(n1);
                            
                            System.out.println("\nExercícios");
                            System.out.println("[1]- Escrever número por extenso");
                            System.out.println("[2]- Escrever invertido");
                            System.out.println("[0]- Sair");
                    }
                    break;
                }
            } while (opcao != 0);
        }
    }

